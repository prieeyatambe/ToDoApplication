import { Container } from "react-bootstrap";
import ListOfTask from "./Component/ListOfTask";
import NavBar from "./Component/Navbar";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import ToDoTasks from "./Component/ToDoTasks";


const App=()=>{
  return(
    <>
    <BrowserRouter>
    <NavBar></NavBar>
    <Container>
      <Switch>
        <Route path="/todos" component={ListOfTask}></Route>
        <Route path="/edit-task/:id" component={ToDoTasks}></Route>
        <Route path="/tasks" component={ToDoTasks}></Route>
        <Route path="/add-task" component={ToDoTasks}></Route>
      </Switch>
    </Container>
    </BrowserRouter>
    </>
  )
}
export default App;