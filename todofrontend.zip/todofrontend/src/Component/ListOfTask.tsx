import { useEffect, useState } from "react";
import { deleteTask, getAllTask, taskCompleted, taskInCompleted } from "../Service/ToDoTaskService";
import { error } from "console";
import { Button, Container, Table } from "react-bootstrap";
import ToDoTask from "../Model/ToDoTask";
import '../Component/todo.css';
import { Link, useHistory, useParams } from "react-router-dom";
import { faTrashCan } from "@fortawesome/free-regular-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheck, faCircleXmark, faPen, faPlus } from "@fortawesome/free-solid-svg-icons";
interface RouteParams {
    id: string;
}
const ListOfTask = () => {

    const [tasks, setTaskList] = useState<ToDoTask[]>([]);
    const navigator = useHistory();
    const { id } = useParams<RouteParams>();

    function getTasksList() {
        getAllTask().then((response) => { setTaskList(response.data) }).catch((error) => console.log(error))
    }
    useEffect(() => getTasksList(), [])

    function deleteTaskById(id: number) {
        deleteTask(id).then((response) => {
            console.log(response.data);
            getTasksList()
        }).catch((error) => console.log(error))
    }

    function updateTask(id: number) {
        navigator.push(`/edit-task/${id}`)
    }



    const [completed, setCompleted] = useState<string>('No');

    const handleCompleteTask = (id: any) => {
        console.log("inside complete");
        taskCompleted(Number(id)).then((response) => {
            getTasksList();
            setCompleted(response.data.completed);
        }).catch((error) => console.log(error))
    }

    const handleInCompleteTask = (id: any) => {
        console.log("inside incomplete");
        taskInCompleted(Number(id)).then((response) => {
            getTasksList();
            setCompleted(response.data.completed);
        }).catch((error) => console.log(error))
    }


    return (
        <>
            <div className="animation-div" style={{ margin: 0, height: 600, width: 1300 }}>
                <h1 className="main" style={{ marginTop: 20 }}>List Of ToDo's</h1>
                <Link to="/add-task" className="btn-style" title="Creates New Task" ><FontAwesomeIcon icon={faPlus} style={{ color: "#edeff3", }} />Add Task</Link>
                <Container style={{ marginLeft: 30, marginTop: 20 }} className="scroll-div">
                    <Table striped bordered hover style={{ textAlign: "center", marginTop: 25, width: 900, marginLeft: 140, padding: 5 }} >
                        <thead style={{ backgroundColor: "black", fontSize: 16, fontWeight: "bold" }}>
                            <tr  >
                                <th style={{ backgroundColor: "black", color: "white" }}>Title</th>
                                <th style={{ backgroundColor: "black", color: "white" }}>Description</th>
                                <th style={{ backgroundColor: "black", color: "white" }}>Completed</th>
                                <th style={{ backgroundColor: "black", color: "white" }}>Action</th>
                            </tr>
                        </thead>
                        <tbody style={{ fontSize: 14, padding: 2 }} >
                            {
                                tasks.map((task) => {
                                    return (
                                        <tr key={task.id}>
                                            <td>{task.title}</td>
                                            <td>{task.description}</td>
                                            <td>{task.completed ? 'Yes' : 'No'}</td>
                                            <td><Button variant="light" onClick={() => updateTask(task.id)} title="Update"><FontAwesomeIcon icon={faPen} size="lg" style={{ color: "green" }} /></Button>&ensp;
                                                <Button variant="light" onClick={() => deleteTaskById(task.id)} title="Delete"><FontAwesomeIcon icon={faTrashCan} size="lg" style={{ color: "red" }} /></Button>&ensp;
                                                <Button variant="light" onClick={() => handleCompleteTask(task.id)} title="Complete"><FontAwesomeIcon icon={faCheck} size="lg" style={{ color: "blue", }} /></Button>&ensp;
                                                <Button variant="light" onClick={() => handleInCompleteTask(task.id)} title="InComplete"><FontAwesomeIcon icon={faCircleXmark} size="lg" style={{ color: "#eebf20", }} /></Button>&ensp;
                                            </td>
                                        </tr>
                                    )
                                })
                            }
                        </tbody>
                    </Table>
                </Container>

            </div>
        </>
    )
}
export default ListOfTask;