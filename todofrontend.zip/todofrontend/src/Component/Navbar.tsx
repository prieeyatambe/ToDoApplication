import { Button, Col, Container, Form, Nav, Navbar, Row } from "react-bootstrap";
import '../Component/todo.css';
import { faListCheck } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const NavBar = () => {

    return (
        <>
            <Navbar className="animation-nav" >
                <Container >
                    <Navbar.Brand style={{ fontSize: 30 }}>
                        <FontAwesomeIcon icon={faListCheck} style={{ color: "royalblue", }} title="To do management application performs CRUD operation.
                     Implementated by using Spring REST API's and ReactJS technologies " />&ensp;
                        ToDo Management Appplication</Navbar.Brand>
                    <Nav className="me-auto">
                        <Nav.Link href="/todos">ToDo's</Nav.Link>
                    </Nav>
                </Container>
            </Navbar>
        </>
    )
}
export default NavBar;