import { FormEvent, SetStateAction, useEffect, useState } from "react";
import { useHistory, useParams } from "react-router-dom";
import { createTask, getTaskById, updateTaskById } from "../Service/ToDoTaskService";
import { error } from "console";
import { Container, Form } from "react-bootstrap";

interface RouteParams {
    id: string
}
interface todotask {
    id: number;
    title: string;
    description: string;
    completed: string;
}
const ToDoTasks = () => {

    const [title, setTitle] = useState<string>('')
    const [description, setDescription] = useState<string>('')
    const [completed, setCompleted] = useState<string>('')

    const { id } = useParams<RouteParams>();

    const navigator = useHistory();

    useEffect(
        () => {
            getTaskById(Number(id)).then((response) => {
                setTitle(response.data.title);
                setDescription(response.data.description);
                setCompleted(response.data.completed)
            }).catch((error) => console.log(error));
        }
        , [id])


    /* update or create */
    function updateTask(e: FormEvent) {
        e.preventDefault();

        const task = { title, description, completed }

        console.log(task);

        if (id) {
            updateTaskById(Number(id), task).then((response) => {
                console.log(response.data);
                navigator.push('/tasks');
            }).catch((error) => {
                console.log(error);
            })
        } else {
            createTask(task).then((response) => {
                console.log(response.data);
                alert("Task added successfully👍");
                navigator.push('/tasks')
            }).catch((error) =>
                console.log(error));
        }
    }
    function pageTitle() {
        if (id) {
            return <h2 className='text-center'>Update ToDo Task</h2>
        } else {
            return <h2 className='text-center'>Add Task</h2>
        }
    }
    return (
        <>
            <Container style={{ width: 500 }}>
                {pageTitle()}
                <Form>
                    <Form.Group className="mb-3">
                        <Form.Label> Title </Form.Label>
                        <Form.Control type="text" value={title} placeholder="Enter title " onChange={(e) => setTitle(e.target.value)} />
                    </Form.Group>

                    <Form.Group className="mb-3">
                        <Form.Label>Description</Form.Label>
                        <Form.Control type="text" value={description} placeholder="Enter description" onChange={(e) => setDescription(e.target.value)} />
                    </Form.Group>


                    <button className="btn btn-warning" onClick={(e) => updateTask(e)} >
                        Submit
                    </button>
                </Form>
            </Container>
        </>
    )
}
export default ToDoTasks;