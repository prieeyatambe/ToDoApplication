type ToDoTask = {
    id: number,
    title: string,
    description: string,
    completed: boolean
}
export default ToDoTask;