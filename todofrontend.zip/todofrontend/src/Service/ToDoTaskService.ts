import axios from "axios"

const TODO_REST_API_BASE_URL = "http://localhost:8070/api/todotask"

export const createTask = (todotask: any) => axios.post(TODO_REST_API_BASE_URL, todotask)

export const getTaskById = (todotaskId: number) => axios.get(TODO_REST_API_BASE_URL + '/' + todotaskId)

export const updateTaskById = (todotaskId: number, todotask: any) => axios.put(TODO_REST_API_BASE_URL + '/' + todotaskId, todotask)

export const deleteTask = (todotaskId: number) => axios.delete(TODO_REST_API_BASE_URL + '/' + todotaskId)

export const getAllTask = () => axios.get(TODO_REST_API_BASE_URL)

export const taskCompleted = (todotaskId: number) => axios.put(TODO_REST_API_BASE_URL + '/' + todotaskId + '/complete');

export const taskInCompleted = (taskId: number) => axios.put(TODO_REST_API_BASE_URL + '/' + taskId + '/incomplete');
